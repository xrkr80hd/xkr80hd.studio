Fixture Noir — XCE Studios delivery (2026-11-09)

For each shot folder, in order, in videoexpress.ai image-to-video (first/last frame mode):
  1. First frame  = first_frame.png
  2. Last frame   = last_frame.png
  3. Prompt       = paste animation_prompt.txt
  4. Duration     = see shot_manifest.json
Name each returned clip <SHOT_ID>.mp4 so Post-Production can conform it.

Shot order:
  01. SC01-SH01 (6 s)  ->  SC01/SC01-SH01/
  02. SC01-SH02 (4 s)  ->  SC01/SC01-SH02/
